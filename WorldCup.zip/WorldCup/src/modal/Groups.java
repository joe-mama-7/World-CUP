package modal;


import java.util.ArrayList;

public class Groups {
    String  name;
    ArrayList<Teams> teams;

}
